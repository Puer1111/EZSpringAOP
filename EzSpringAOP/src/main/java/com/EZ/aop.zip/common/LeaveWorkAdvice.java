package com.EZ.aop.common;

public class LeaveWorkAdvice {

	public void printLeaveWorkTime() {
		System.out.println("퇴근요");
	}
}
