package com.EZ.aop.common;

public class GoWorkAdvice {

	public void printGoWorkTime() {
		System.out.println("출근");
	}
}
